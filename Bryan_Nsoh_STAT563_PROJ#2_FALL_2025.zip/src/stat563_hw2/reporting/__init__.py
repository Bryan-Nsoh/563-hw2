"""Reporting utilities for STAT 563 HW2."""

from .render import build_report

__all__ = ["build_report"]
